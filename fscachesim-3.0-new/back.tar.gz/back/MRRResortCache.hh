#ifndef _MRRRESORTCache_HH_
#define _MRRRESORTCache_HH_

using namespace std;

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#include <assert.h>
#include <map>

#ifdef HAVE_STDINT_H
#include <stdint.h>
#endif /* HAVE_STDINT_H */
#include <stdio.h>

#include "MemoryRegion.hh"
#include "MRRCache.hh"


class MRRResortCache : public MRRCache {
private:

  typedef multimap<double,
	      list<MemoryRegion::memory_region_t>::iterator> ResortIndex;

  typedef pair <double,
	      list<MemoryRegion::memory_region_t>::iterator> pair_resort;

  ResortIndex evictIndex;

  double L;

private:
  // Copy constructors - declared private and never defined

  MRRResortCache(const MRRResortCache&);
  MRRResortCache& operator=(const MRRResortCache&);

protected:

  virtual void EvictCache(uint64_t regsize);
  virtual void sendtotail(RegCacheIndex::iterator& regionIter);

public:

  MRRResortCache(uint64_t inCacheSize) :
    MRRCache(inCacheSize),
    L(0)
    { ; };


  ~MRRResortCache() { ; };


};

#endif /* _MRRRESORTCache_HH_ */
