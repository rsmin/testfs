/*
  RCS:          $Header: /afs/cs.cmu.edu/user/tmwong/Cvs/fscachesim/StoreCache.cc,v 1.4 2002/02/18 00:23:45 tmwong Exp $
  Author:       T.M. Wong <tmwong+@cs.cmu.edu>
*/
 
#include <list>
#ifdef HAVE_STDINT_H
#include <stdint.h>
#endif /* HAVE_STDINT_H */
#include <stdio.h>
#include <stdlib.h>


#include "IORequest.hh"
#include "Store.hh"
#include "StoreRegCache.hh"


bool
StoreRegCache::IORequestDown(const IORequest& inIOReq)
{
  MemoryRegion::memory_region_t mr = {inIOReq.objIDGet(), inIOReq.blockOffGet(blockSize),  \
                                inIOReq.blockLenGet(blockSize)};


  cache->RegionRef(mr);

  return (true);
}


void
StoreRegCache::statisticsShow() const
{

  printf("{StoreRegCache.%s\n", nameGet());
  cache->statisticsShow();
  printf("}\n");
}



