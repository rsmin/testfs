#include <list>
#include <stdio.h>
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif /* HAVE_STDLIB_H */

#include "MemoryRegion.hh"


#include "MRRResortCache.hh"



void MRRResortCache::EvictCache(uint64_t regsize)
{
  
    uint64_t resortsize = blockCountMax/5;
    uint64_t evictsize = resortsize/2;

    uint64_t unregsize = 0;

    if (regsize > resortsize)
       return RegCache::EvictCache(regsize);
      
    list<MemoryRegion::memory_region_t>::iterator cacheIter;
    for (cacheIter = cache.begin();   
          cacheIter != cache.end() && unregsize < resortsize; cacheIter++)
    {
       unregsize += cacheIter->len;
       if (cacheIter->H == 0)
           cacheIter->H = L + (double)1/(double)cacheIter->len;
       evictIndex.insert(pair_resort (cacheIter->H, cacheIter));
    }

    unregsize = 0;
    ResortIndex::iterator resIter;

    for (resIter = evictIndex.begin(); resIter != evictIndex.end() && (unregsize < evictsize);
         resIter++) 
    {
//         printf ("res \t%llu\t%llu\t%llu\t%lf\n",resIter->second->objID, 
//          resIter->second->blockID, resIter->second->len,resIter->second->H);

         unregsize += resIter->second->len;
         blockCount -= resIter->second->len;
         L = resIter->second->H;
         cache.erase(resIter->second);       
    }

    evictIndex.clear();

    totaltime += unregsize*DISREG_PERPAGE + DISREG_PERREG;
    assert(blockCount > 0);

}


void MRRResortCache::sendtotail(RegCacheIndex::iterator& regionIter) 
{
   regionIter->second->H = 0;
   RegCache::sendtotail(regionIter);
}
